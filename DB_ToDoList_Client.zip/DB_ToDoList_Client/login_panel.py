from PyQt6.QtWidgets import QWidget, QLabel, QLineEdit, QPushButton, QVBoxLayout, QMessageBox
from DAO.user_DAO import UserDAO
import hashlib
from typing import TYPE_CHECKING
from session import Session

if TYPE_CHECKING:
    from main import MainWindow

class LoginPanel(QWidget):
    def __init__(self, parent: 'MainWindow' = None):
        super().__init__(parent)
        self.parent_window = parent
        self.user_dao = UserDAO()
        self.session = Session()
        self.init_ui()

    def init_ui(self):
        self.layout = QVBoxLayout()

        self.username_label = QLabel("Имя пользователя:")
        self.username_edit = QLineEdit()
        self.layout.addWidget(self.username_label)
        self.layout.addWidget(self.username_edit)

        self.password_label = QLabel("Пароль:")
        self.password_edit = QLineEdit()
        self.password_edit.setEchoMode(QLineEdit.EchoMode.Password)
        self.layout.addWidget(self.password_label)
        self.layout.addWidget(self.password_edit)

        self.login_button = QPushButton("Войти")
        self.login_button.clicked.connect(self.login)
        self.layout.addWidget(self.login_button)

        self.setLayout(self.layout)

    def login(self):
        username = self.username_edit.text()
        password = self.password_edit.text()

        user = self.user_dao.get_user_by_username(username)
        if user:
            password_hash = hashlib.pbkdf2_hmac('sha256', password.encode('utf-8'), bytes.fromhex(user.get_password_salt()), 100000).hex()
            if password_hash == user.get_password_hash():
                self.session.set_user_id(user.get_user_id())
                QMessageBox.information(self, "Успех", "Авторизация прошла успешно")
                if user.get_role() == 'admin':
                    self.parent_window.show_admin_panel()
                else:
                    self.parent_window.show_task_list()
            else:
                QMessageBox.warning(self, "Ошибка", "Неверный пароль")
        else:
            QMessageBox.warning(self, "Ошибка", "Пользователь не найден")