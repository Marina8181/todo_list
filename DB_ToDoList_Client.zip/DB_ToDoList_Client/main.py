from PyQt6.QtWidgets import QApplication, QMainWindow, QVBoxLayout, QWidget, QMessageBox
from login_panel import LoginPanel
from admin_panel import AdminPanel
from user_task_panel import UserTaskPanel
from session import Session


class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Авторизация")
        self.setGeometry(100, 100, 400, 200)

        self.central_widget = QWidget()
        self.setCentralWidget(self.central_widget)
        self.layout = QVBoxLayout(self.central_widget)

        self.login_panel = LoginPanel(self)
        self.layout.addWidget(self.login_panel)

    def show_admin_panel(self):
        session = Session()
        self.admin_panel = AdminPanel()
        self.admin_panel.show()
        self.close()

    def show_task_list(self):
        session = Session()
        self.user_task_panel = UserTaskPanel()
        self.user_task_panel.show()
        self.close()


def main():
    app = QApplication([])
    main_window = MainWindow()
    main_window.show()
    app.exec()


if __name__ == "__main__":
    main()
