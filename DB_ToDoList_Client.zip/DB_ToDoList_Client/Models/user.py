class User:
    def __init__(self, user_id, username, password_hash, password_salt, email, role):
        self.user_id = user_id
        self.username = username
        self.password_hash = password_hash
        self.password_salt = password_salt
        self.email = email
        self.role = role

    # Геттеры и сеттеры
    def get_user_id(self):
        return self.user_id

    def set_user_id(self, user_id):
        self.user_id = user_id

    def get_username(self):
        return self.username

    def set_username(self, username):
        self.username = username

    def get_password_hash(self):
        return self.password_hash

    def set_password_hash(self, password_hash):
        self.password_hash = password_hash

    def get_password_salt(self):
        return self.password_salt

    def set_password_salt(self, password_salt):
        self.password_salt = password_salt

    def get_email(self):
        return self.email

    def set_email(self, email):
        self.email = email

    def get_role(self):
        return self.role

    def set_role(self, role):
        self.role = role

    def get_user_details(self):
        return (f"User ID: {self.user_id}, Username: {self.username}, "
                f"Email: {self.email}, Role: {self.role}")

    # Метод для вывода информации о пользователе
    def __str__(self):
        return (f"Пользователь {self.user_id} - Имя пользователя: {self.username}, "
                f"Email: {self.email}, Роль: {self.role}")