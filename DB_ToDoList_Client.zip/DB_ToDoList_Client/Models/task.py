class Task:
    def __init__(self, task_id, user_id, title, task_description, start_date, end_date, category_id, status="В ожидании"):
        self.task_id = task_id
        self.user_id = user_id
        self.title = title
        self.task_description = task_description
        self.start_date = start_date
        self.end_date = end_date
        self.category_id = category_id
        self.status = status

    # Геттеры и сеттеры
    def get_task_id(self):
        return self.task_id

    def set_task_id(self, task_id):
        self.task_id = task_id

    def get_user_id(self):
        return self.user_id

    def set_user_id(self, user_id):
        self.user_id = user_id

    def get_title(self):
        return self.title

    def set_title(self, title):
        self.title = title

    def get_task_description(self):
        return self.task_description

    def set_task_description(self, task_description):
        self.task_description = task_description

    def get_start_date(self):
        return self.start_date

    def set_start_date(self, start_date):
        self.start_date = start_date

    def get_end_date(self):
        return self.end_date

    def set_end_date(self, end_date):
        self.end_date = end_date

    def get_category_id(self):
        return self.category_id

    def set_category_id(self, category_id):
        self.category_id = category_id

    def get_status(self):
        return self.status

    def set_status(self, status):
        if status not in ["В ожидании", "В работе", "Завершена"]:
            raise ValueError("Неверный статус задачи")
        self.status = status

    def get_task_details(self):
        return (f"Task ID: {self.task_id}, User ID: {self.user_id}, Title: {self.title}, "
                f"Description: {self.task_description}, Start Date: {self.start_date}, End Date: {self.end_date}, "
                f"Category ID: {self.category_id}, Status: {self.status}")

    # Метод для вывода информации о задаче
    def __str__(self):
        return (f"Задача {self.task_id} - Название: {self.title}, Описание: {self.task_description}, "
                f"Дата начала: {self.start_date}, Дата окончания: {self.end_date}, Категория ID: {self.category_id}, Статус: {self.status}")
