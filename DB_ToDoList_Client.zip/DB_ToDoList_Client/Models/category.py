class Category:
    def __init__(self, category_id, category_name):
        self.category_id = category_id
        self.category_name = category_name

    # Геттеры и сеттеры
    def get_category_id(self):
        return self.category_id

    def set_category_id(self, category_id):
        self.category_id = category_id

    def get_category_name(self):
        return self.category_name

    def set_category_name(self, category_name):
        self.category_name = category_name

    def get_category_details(self):
        return f"Category ID: {self.category_id}, Category Name: {self.category_name}"

    # Метод для вывода информации о категории
    def __str__(self):
        return f"Категория {self.category_id} - Название: {self.category_name}"
