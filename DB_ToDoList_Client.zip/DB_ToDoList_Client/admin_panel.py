from PyQt6.QtWidgets import QMainWindow, QWidget, QVBoxLayout, QPushButton, QStackedWidget, QMessageBox, QApplication
from Panels.user_panel import UserPanel
from Panels.category_panel import CategoryPanel
from Panels.task_panel import TaskPanel

class AdminPanel(QMainWindow):
    def __init__(self):
        super().__init__()
        # Настройка основного окна приложения
        self.setWindowTitle("Панель администратора")
        self.setGeometry(100, 100, 1200, 700)

        # Создание центрального виджета и основного макета
        self.central_widget = QWidget()
        self.setCentralWidget(self.central_widget)
        self.main_layout = QVBoxLayout(self.central_widget)

        # Создание фрейма для навигации и его макета
        self.navigation_frame = QWidget()
        self.nav_layout = QVBoxLayout(self.navigation_frame)

        # Создание кнопок навигации
        self.create_navigation_buttons()

        # Создание фрейма для отображения содержимого и его макета
        self.content_frame = QStackedWidget()

        # Создание панелей содержимого
        self.create_content_panels()

        # Добавление фреймов навигации и содержимого в основной макет
        self.main_layout.addWidget(self.navigation_frame)
        self.main_layout.addWidget(self.content_frame)

    def create_navigation_buttons(self):
        # Создание кнопок навигации и добавление их в макет
        buttons = [
            ("Пользователи", self.show_user_panel),
            ("Категории", self.show_category_panel),
            ("Задачи", self.show_task_panel),
            ("Выход", self.exit_application)
        ]

        for (text, command) in buttons:
            button = QPushButton(text)
            button.clicked.connect(command)
            self.nav_layout.addWidget(button)

        self.navigation_frame.setLayout(self.nav_layout)

    def create_content_panels(self):
        # Создание панелей содержимого и добавление их в QStackedWidget
        self.content_panels = {}

        self.user_panel = UserPanel()
        self.content_panels["Пользователи"] = self.user_panel

        self.category_panel = CategoryPanel()
        self.content_panels["Категории"] = self.category_panel

        self.task_panel = TaskPanel()
        self.content_panels["Задачи"] = self.task_panel

        self.content_frame.addWidget(self.user_panel)
        self.content_frame.addWidget(self.category_panel)
        self.content_frame.addWidget(self.task_panel)

    def show_user_panel(self):
        # Отображение панели "Пользователи"
        self.show_panel("Пользователи")

    def show_category_panel(self):
        # Отображение панели "Категории"
        self.show_panel("Категории")

    def show_task_panel(self):
        # Отображение панели "Задачи"
        self.show_panel("Задачи")

    def show_panel(self, panel_name):
        # Отображение панели по имени
        panel = self.content_panels.get(panel_name)
        if panel:
            self.content_frame.setCurrentWidget(panel)

    def exit_application(self):
        # Подтверждение выхода из приложения
        confirm = QMessageBox.question(self, "Подтверждение выхода", "Вы уверены, что хотите выйти?")
        if confirm == QMessageBox.StandardButton.Yes:
            QApplication.instance().quit()
