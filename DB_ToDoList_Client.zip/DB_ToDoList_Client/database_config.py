class DatabaseConfig:
    _host = "localhost"
    _port = 3306
    _database = "todo_list"
    _username = "root"
    _password = "TRIceratops122#$"

    @classmethod
    def get_host(cls):
        return cls._host

    @classmethod
    def get_port(cls):
        return cls._port

    @classmethod
    def get_database(cls):
        return cls._database

    @classmethod
    def get_username(cls):
        return cls._username

    @classmethod
    def get_password(cls):
        return cls._password

    @classmethod
    def get_connection_url(cls):
        return f"mysql+mysqlconnector://{cls._username}:{cls._password}@{cls._host}:{cls._port}/{cls._database}"

    @classmethod
    def get_config(cls):
        return {
            'host': cls._host,
            'port': cls._port,
            'database': cls._database,
            'user': cls._username,
            'password': cls._password
        }