from PyQt6.QtWidgets import QDialog, QLabel, QLineEdit, QPushButton, QVBoxLayout, QHBoxLayout, QComboBox, QMessageBox
from DAO.user_DAO import UserDAO
from Models.user import User


class AddEditUserDialog(QDialog):
    def __init__(self, parent=None, user=None, user_dao=None):
        super().__init__(parent)
        # Инициализация DAO для работы с данными о пользователях
        self.user_dao = user_dao
        self.user = user if user else User(0, "", "", "", "", "")

        # Настройка диалогового окна
        self.setWindowTitle("Добавить пользователя" if user is None else "Редактировать пользователя")
        self.setModal(True)
        self.setFixedSize(400, 300)
        self.init_ui()
        self.load_user_data()

    def init_ui(self):
        # Создание и настройка элементов интерфейса
        self.layout = QVBoxLayout()

        self.id_label = QLabel("ID пользователя:")
        self.id_edit = QLineEdit()
        self.id_edit.setDisabled(True)
        self.layout.addWidget(self.id_label)
        self.layout.addWidget(self.id_edit)

        self.username_label = QLabel("Имя пользователя:")
        self.username_edit = QLineEdit()
        self.layout.addWidget(self.username_label)
        self.layout.addWidget(self.username_edit)

        self.email_label = QLabel("Электронная почта:")
        self.email_edit = QLineEdit()
        self.layout.addWidget(self.email_label)
        self.layout.addWidget(self.email_edit)

        self.role_label = QLabel("Роль:")
        self.role_combobox = QComboBox()
        self.role_combobox.addItems(["admin", "user"])
        self.layout.addWidget(self.role_label)
        self.layout.addWidget(self.role_combobox)

        self.password_label = QLabel("Пароль:")
        self.password_edit = QLineEdit()
        self.password_edit.setEchoMode(QLineEdit.EchoMode.Password)
        self.layout.addWidget(self.password_label)
        self.layout.addWidget(self.password_edit)

        self.button_box = QHBoxLayout()
        self.save_button = QPushButton("Сохранить")
        self.save_button.clicked.connect(self.save_user)
        self.cancel_button = QPushButton("Отмена")
        self.cancel_button.clicked.connect(self.cancel)
        self.button_box.addWidget(self.save_button)
        self.button_box.addWidget(self.cancel_button)
        self.layout.addLayout(self.button_box)

        self.setLayout(self.layout)

    def load_user_data(self):
        # Загрузка данных о пользователе в элементы интерфейса
        if self.user:
            self.id_edit.setText(str(self.user.get_user_id()))
            self.username_edit.setText(self.user.get_username())
            self.email_edit.setText(self.user.get_email())
            self.role_combobox.setCurrentText(self.user.get_role())

    def save_user(self):
        # Сохранение данных о пользователе
        try:
            username = self.username_edit.text()
            email = self.email_edit.text()
            role = self.role_combobox.currentText()
            password = self.password_edit.text()

            if not username or not email or not password:
                raise ValueError("Все поля должны быть заполнены")

            # Хеширование пароля и генерация соли (упрощенная реализация)
            import hashlib, os
            salt = os.urandom(32)
            password_hash = hashlib.pbkdf2_hmac('sha256', password.encode('utf-8'), salt, 100000)
            password_hash = password_hash.hex()
            salt = salt.hex()

            self.user.set_username(username)
            self.user.set_email(email)
            self.user.set_role(role)
            self.user.set_password_hash(password_hash)
            self.user.set_password_salt(salt)

            if self.user.get_user_id() == 0:
                self.user_dao.add_user(self.user)
            else:
                self.user_dao.update_user(self.user)

            self.accept()
        except Exception as ex:
            QMessageBox.critical(self, "Ошибка", f"Ошибка: {ex}")

    def cancel(self):
        # Отмена редактирования/добавления и закрытие диалогового окна
        self.reject()

    def get_user(self):
        # Возвращает объект пользователя
        return self.user
