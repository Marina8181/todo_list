from PyQt6.QtWidgets import QDialog, QLabel, QLineEdit, QPushButton, QVBoxLayout, QHBoxLayout, QComboBox, QMessageBox, QDateTimeEdit
from PyQt6.QtCore import QDateTime
from Models.task import Task
from DAO.task_DAO import TaskDAO
from DAO.user_DAO import UserDAO
from DAO.category_DAO import CategoryDAO
import datetime

class AddEditTaskDialog(QDialog):
    def __init__(self, parent=None, task=None, task_dao=None, user_id=None):
        super().__init__(parent)
        # Инициализация DAO для работы с данными о задачах, пользователях и категориях
        self.task_dao = task_dao
        self.task = task if task else Task(0, user_id, "", "", "", "", "", "В ожидании")
        self.user_dao = UserDAO()
        self.category_dao = CategoryDAO()
        self.user_id = user_id

        # Настройка диалогового окна
        self.setWindowTitle("Добавить задачу" if task is None else "Редактировать задачу")
        self.setModal(True)
        self.setFixedSize(400, 500)
        self.init_ui()
        self.load_task_data()

    def init_ui(self):
        # Создание и настройка элементов интерфейса
        self.layout = QVBoxLayout()

        self.id_label = QLabel("ID задачи:")
        self.id_edit = QLineEdit()
        self.id_edit.setDisabled(True)
        self.layout.addWidget(self.id_label)
        self.layout.addWidget(self.id_edit)

        self.user_label = QLabel("Пользователь:")
        self.user_combobox = QComboBox()
        self.layout.addWidget(self.user_label)
        self.layout.addWidget(self.user_combobox)

        self.title_label = QLabel("Название:")
        self.title_edit = QLineEdit()
        self.layout.addWidget(self.title_label)
        self.layout.addWidget(self.title_edit)

        self.description_label = QLabel("Описание:")
        self.description_edit = QLineEdit()
        self.layout.addWidget(self.description_label)
        self.layout.addWidget(self.description_edit)

        self.start_date_label = QLabel("Дата начала:")
        self.start_date_edit = QDateTimeEdit()
        self.start_date_edit.setDisplayFormat("yyyy-MM-dd HH:mm:ss")
        self.start_date_edit.setCalendarPopup(True)
        self.layout.addWidget(self.start_date_label)
        self.layout.addWidget(self.start_date_edit)

        self.end_date_label = QLabel("Дата окончания:")
        self.end_date_edit = QDateTimeEdit()
        self.end_date_edit.setDisplayFormat("yyyy-MM-dd HH:mm:ss")
        self.end_date_edit.setCalendarPopup(True)
        self.layout.addWidget(self.end_date_label)
        self.layout.addWidget(self.end_date_edit)

        self.category_label = QLabel("Категория:")
        self.category_combobox = QComboBox()
        self.layout.addWidget(self.category_label)
        self.layout.addWidget(self.category_combobox)

        self.status_label = QLabel("Статус:")
        self.status_combobox = QComboBox()
        self.status_combobox.addItems(["В ожидании", "В работе", "Завершена"])
        self.layout.addWidget(self.status_label)
        self.layout.addWidget(self.status_combobox)

        self.button_box = QHBoxLayout()
        self.save_button = QPushButton("Сохранить")
        self.save_button.clicked.connect(self.save_task)
        self.cancel_button = QPushButton("Отмена")
        self.cancel_button.clicked.connect(self.cancel)
        self.button_box.addWidget(self.save_button)
        self.button_box.addWidget(self.cancel_button)
        self.layout.addLayout(self.button_box)

        self.setLayout(self.layout)

    def load_task_data(self):
        # Загрузка данных о задаче в элементы интерфейса
        try:
            if self.task:
                self.id_edit.setText(str(self.task.get_task_id()))
                self.title_edit.setText(self.task.get_title())
                self.description_edit.setText(self.task.get_task_description())

                start_date_str = self.task.get_start_date()
                if isinstance(start_date_str, datetime.datetime):
                    start_date_str = start_date_str.strftime('%Y-%m-%d %H:%M:%S')
                if start_date_str:
                    self.start_date_edit.setDateTime(QDateTime.fromString(start_date_str, "yyyy-MM-dd HH:mm:ss"))

                end_date_str = self.task.get_end_date()
                if isinstance(end_date_str, datetime.datetime):
                    end_date_str = end_date_str.strftime('%Y-%m-%d %H:%M:%S')
                if end_date_str:
                    self.end_date_edit.setDateTime(QDateTime.fromString(end_date_str, "yyyy-MM-dd HH:mm:ss"))

                users = self.user_dao.get_all_users()
                if self.user_id:
                    user = self.user_dao.get_user(self.user_id)
                    self.user_combobox.addItem(f"{user.get_user_id()} - {user.get_username()}")
                    self.user_combobox.setCurrentText(f"{user.get_user_id()} - {user.get_username()}")
                    self.user_combobox.setDisabled(True)
                else:
                    self.user_combobox.addItems([f"{u.get_user_id()} - {u.get_username()}" for u in users])
                    user = self.user_dao.get_user(self.task.get_user_id())
                    if user:
                        self.user_combobox.setCurrentText(f"{user.get_user_id()} - {user.get_username()}")

                categories = self.category_dao.get_all_categories()
                self.category_combobox.addItems([f"{c.get_category_id()} - {c.get_category_name()}" for c in categories])
                category = self.category_dao.get_category(self.task.get_category_id())
                if category:
                    self.category_combobox.setCurrentText(f"{category.get_category_id()} - {category.get_category_name()}")

                self.status_combobox.setCurrentText(self.task.get_status())
        except Exception as ex:
            QMessageBox.critical(self, "Ошибка", f"Ошибка при загрузке данных задачи: {ex}")

    def save_task(self):
        # Сохранение данных о задаче
        try:
            user_id = int(self.user_combobox.currentText().split(" - ")[0])
            title = self.title_edit.text()
            description = self.description_edit.text()
            start_date = self.start_date_edit.dateTime().toString("yyyy-MM-dd HH:mm:ss")
            end_date = self.end_date_edit.dateTime().toString("yyyy-MM-dd HH:mm:ss")
            category_id = int(self.category_combobox.currentText().split(" - ")[0])
            status = self.status_combobox.currentText()

            self.task.set_user_id(user_id)
            self.task.set_title(title)
            self.task.set_task_description(description)
            self.task.set_start_date(start_date)
            self.task.set_end_date(end_date)
            self.task.set_category_id(category_id)
            self.task.set_status(status)

            if self.task.get_task_id() == 0:
                self.task_dao.add_task(self.task)
            else:
                self.task_dao.update_task(self.task)

            self.accept()
        except Exception as ex:
            QMessageBox.critical(self, "Ошибка", f"Ошибка при сохранении данных задачи: {ex}")

    def cancel(self):
        # Отмена редактирования/добавления и закрытие диалогового окна
        self.reject()

    def get_task(self):
        # Возвращает объект задачи
        return self.task
