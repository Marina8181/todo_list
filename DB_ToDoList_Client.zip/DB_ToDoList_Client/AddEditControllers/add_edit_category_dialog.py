from PyQt6.QtWidgets import QDialog, QLabel, QLineEdit, QPushButton, QVBoxLayout, QHBoxLayout, QMessageBox
from Models.category import Category
from DAO.category_DAO import CategoryDAO

class AddEditCategoryDialog(QDialog):
    def __init__(self, parent=None, category=None, category_dao=None):
        super().__init__(parent)
        # Инициализация DAO для работы с данными о категориях
        self.category_dao = category_dao
        self.category = category if category else Category(0, "")

        # Настройка диалогового окна
        self.setWindowTitle("Добавить категорию" if category is None else "Редактировать категорию")
        self.setModal(True)
        self.setFixedSize(400, 200)
        self.init_ui()
        self.load_category_data()

    def init_ui(self):
        # Создание и настройка элементов интерфейса
        self.layout = QVBoxLayout()

        self.id_label = QLabel("ID категории:")
        self.id_edit = QLineEdit()
        self.id_edit.setDisabled(True)
        self.layout.addWidget(self.id_label)
        self.layout.addWidget(self.id_edit)

        self.name_label = QLabel("Название категории:")
        self.name_edit = QLineEdit()
        self.layout.addWidget(self.name_label)
        self.layout.addWidget(self.name_edit)

        self.button_box = QHBoxLayout()
        self.save_button = QPushButton("Сохранить")
        self.save_button.clicked.connect(self.save_category)
        self.cancel_button = QPushButton("Отмена")
        self.cancel_button.clicked.connect(self.cancel)
        self.button_box.addWidget(self.save_button)
        self.button_box.addWidget(self.cancel_button)
        self.layout.addLayout(self.button_box)

        self.setLayout(self.layout)

    def load_category_data(self):
        # Загрузка данных о категории в элементы интерфейса
        if self.category:
            self.id_edit.setText(str(self.category.get_category_id()))
            self.name_edit.setText(self.category.get_category_name())

    def save_category(self):
        # Сохранение данных о категории
        try:
            category_name = self.name_edit.text()

            if not category_name:
                raise ValueError("Название категории не может быть пустым")

            self.category.set_category_name(category_name)

            if self.category.get_category_id() == 0:
                self.category_dao.add_category(self.category)
            else:
                self.category_dao.update_category(self.category)

            self.accept()
        except Exception as ex:
            QMessageBox.critical(self, "Ошибка", f"Ошибка: {ex}")

    def cancel(self):
        # Отмена редактирования/добавления и закрытие диалогового окна
        self.reject()

    def get_category(self):
        # Возвращает объект категории
        return self.category
