from PyQt6.QtCore import Qt, QAbstractTableModel
from PyQt6.QtGui import QColor
from PyQt6.QtWidgets import QTableView, QHeaderView


class TaskTableModel(QAbstractTableModel):
    def __init__(self, tasks=None):
        super().__init__()
        self.tasks = tasks if tasks else []
        self.headers = ["ID", "Имя пользователя", "Название", "Описание", "Дата начала", "Дата окончания", "Категория",
                        "Статус"]

    def rowCount(self, parent=None):
        return len(self.tasks)

    def columnCount(self, parent=None):
        return len(self.headers)

    def data(self, index, role=Qt.ItemDataRole.DisplayRole):
        if role == Qt.ItemDataRole.DisplayRole:
            task = self.tasks[index.row()]
            if index.column() == 0:
                return task.get_task_id()
            elif index.column() == 1:
                return task.get_user_id()
            elif index.column() == 2:
                return task.get_title()
            elif index.column() == 3:
                return task.get_task_description()
            elif index.column() == 4:
                return task.get_start_date().strftime('%Y-%m-%d %H:%M:%S')
            elif index.column() == 5:
                return task.get_end_date().strftime('%Y-%m-%d %H:%M:%S')
            elif index.column() == 6:
                return task.get_category_id()
            elif index.column() == 7:
                return task.get_status()
        if role == Qt.ItemDataRole.BackgroundRole:
            task = self.tasks[index.row()]
            if task.get_status() == "Завершена":
                return QColor(Qt.GlobalColor.darkGreen)
            elif task.get_status() == "В ожидании":
                return QColor(Qt.GlobalColor.darkRed)
            elif task.get_status() == "В работе":
                return QColor(Qt.GlobalColor.darkYellow)
        return None

    def headerData(self, section, orientation, role=Qt.ItemDataRole.DisplayRole):
        if role == Qt.ItemDataRole.DisplayRole:
            if orientation == Qt.Orientation.Horizontal:
                return self.headers[section]
        return None

    def refresh_data(self, tasks):
        self.tasks = tasks
        self.layoutChanged.emit()

    def get_task_at(self, index):
        if 0 <= index < len(self.tasks):
            return self.tasks[index]
        return None


class TaskTableView(QTableView):
    def __init__(self, tasks=None):
        super().__init__()
        self.model = TaskTableModel(tasks)
        self.setModel(self.model)
        self.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeMode.Stretch)

    def refresh_data(self, tasks):
        self.model.refresh_data(tasks)
