from PyQt6.QtCore import QAbstractTableModel, Qt
from PyQt6.QtWidgets import QTableView, QHeaderView
from Models.category import Category


class CategoryTableModel(QAbstractTableModel):
    def __init__(self, categories=None):
        super().__init__()
        # Инициализация модели таблицы с данными о категориях
        self.categories = categories if categories else []
        self.headers = ["ID", "Название категории"]

    def rowCount(self, parent=None):
        # Возвращает количество строк в таблице
        return len(self.categories)

    def columnCount(self, parent=None):
        # Возвращает количество столбцов в таблице
        return len(self.headers)

    def data(self, index, role=Qt.ItemDataRole.DisplayRole):
        # Возвращает данные для отображения в таблице
        if role == Qt.ItemDataRole.DisplayRole:
            category = self.categories[index.row()]
            if index.column() == 0:
                return category.get_category_id()
            elif index.column() == 1:
                return category.get_category_name()
        return None

    def headerData(self, section, orientation, role=Qt.ItemDataRole.DisplayRole):
        # Возвращает данные заголовков столбцов
        if role == Qt.ItemDataRole.DisplayRole:
            if orientation == Qt.Orientation.Horizontal:
                return self.headers[section]
        return None

    def refresh_data(self, categories):
        # Обновляет данные таблицы
        self.categories = categories
        self.layoutChanged.emit()

    def get_category_at(self, index):
        # Возвращает объект категории по индексу
        if 0 <= index < len(self.categories):
            return self.categories[index]
        return None


class CategoryTableView(QTableView):
    def __init__(self, categories=None):
        super().__init__()
        # Инициализация представления таблицы с данными о категориях
        self.model = CategoryTableModel(categories)
        self.setModel(self.model)
        self.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeMode.Stretch)

    def refresh_data(self, categories):
        # Обновляет данные в модели таблицы
        self.model.refresh_data(categories)
