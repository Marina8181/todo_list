from PyQt6.QtCore import QAbstractTableModel, Qt
from PyQt6.QtWidgets import QTableView, QHeaderView
from Models.user import User


class UserTableModel(QAbstractTableModel):
    def __init__(self, users=None):
        super().__init__()
        # Инициализация модели таблицы с данными о пользователях
        self.users = users if users else []
        self.headers = ["ID", "Имя пользователя", "Электронная почта", "Роль"]

    def rowCount(self, parent=None):
        # Возвращает количество строк в таблице
        return len(self.users)

    def columnCount(self, parent=None):
        # Возвращает количество столбцов в таблице
        return len(self.headers)

    def data(self, index, role=Qt.ItemDataRole.DisplayRole):
        # Возвращает данные для отображения в таблице
        if role == Qt.ItemDataRole.DisplayRole:
            user = self.users[index.row()]
            if index.column() == 0:
                return user.get_user_id()
            elif index.column() == 1:
                return user.get_username()
            elif index.column() == 2:
                return user.get_email()
            elif index.column() == 3:
                return user.get_role()
        return None

    def headerData(self, section, orientation, role=Qt.ItemDataRole.DisplayRole):
        # Возвращает данные заголовков столбцов
        if role == Qt.ItemDataRole.DisplayRole:
            if orientation == Qt.Orientation.Horizontal:
                return self.headers[section]
        return None

    def refresh_data(self, users):
        # Обновляет данные таблицы
        self.users = users
        self.layoutChanged.emit()

    def get_user_at(self, index):
        # Возвращает объект пользователя по индексу
        if 0 <= index < len(self.users):
            return self.users[index]
        return None


class UserTableView(QTableView):
    def __init__(self, users=None):
        super().__init__()
        # Инициализация представления таблицы с данными о пользователях
        self.model = UserTableModel(users)
        self.setModel(self.model)
        self.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeMode.Stretch)

    def refresh_data(self, users):
        # Обновляет данные в модели таблицы
        self.model.refresh_data(users)
