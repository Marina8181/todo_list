import mysql.connector
from PyQt6.QtWidgets import QMessageBox
from Models.user import User
from database_config import DatabaseConfig

class UserDAO:
    def __init__(self):
        self.config = DatabaseConfig.get_config()

    # Метод для добавления пользователя в базу данных
    def add_user(self, user):
        con = None
        try:
            con = mysql.connector.connect(**self.config)
            query = "INSERT INTO Users (Username, PasswordHash, PasswordSalt, Email, Role) VALUES (%s, %s, %s, %s, %s)"
            cur = con.cursor()
            cur.execute(query, (user.get_username(), user.get_password_hash(), user.get_password_salt(), user.get_email(), user.get_role()))
            user.set_user_id(cur.lastrowid)
            con.commit()
        except mysql.connector.Error as ex:
            self.show_error(f"Ошибка при добавлении пользователя: {ex}")
        finally:
            if con:
                con.close()

    # Метод для получения информации о пользователе по его ID
    def get_user(self, user_id):
        user = None
        con = None
        try:
            con = mysql.connector.connect(**self.config)
            query = "SELECT * FROM Users WHERE ID = %s"
            cur = con.cursor()
            cur.execute(query, (user_id,))
            row = cur.fetchone()
            if row:
                user = User(row[0], row[1], row[2], row[3], row[4], row[5])
        except mysql.connector.Error as ex:
            self.show_error(f"Ошибка при получении данных пользователя: {ex}")
        finally:
            if con:
                con.close()
        return user

    def get_user_by_username(self, username):
        user = None
        con = None
        try:
            con = mysql.connector.connect(**self.config)
            query = "SELECT * FROM Users WHERE Username = %s"
            cur = con.cursor()
            cur.execute(query, (username,))
            row = cur.fetchone()
            if row:
                user = User(row[0], row[1], row[2], row[3], row[4], row[5])
        except mysql.connector.Error as ex:
            self.show_error(f"Ошибка при получении данных пользователя: {ex}")
        finally:
            if con:
                con.close()
        return user

    # Метод для обновления информации о пользователе
    def update_user(self, user):
        con = None
        try:
            con = mysql.connector.connect(**self.config)
            query = "UPDATE Users SET Username = %s, PasswordHash = %s, PasswordSalt = %s, Email = %s, Role = %s WHERE ID = %s"
            cur = con.cursor()
            cur.execute(query, (user.get_username(), user.get_password_hash(), user.get_password_salt(), user.get_email(), user.get_role(), user.get_user_id()))
            con.commit()
        except mysql.connector.Error as ex:
            self.show_error(f"Ошибка при обновлении данных пользователя: {ex}")
        finally:
            if con:
                con.close()

    # Метод для удаления информации о пользователе по его ID
    def delete_user(self, user_id):
        con = None
        try:
            con = mysql.connector.connect(**self.config)
            query = "DELETE FROM Users WHERE ID = %s"
            cur = con.cursor()
            cur.execute(query, (user_id,))
            con.commit()
        except mysql.connector.Error as ex:
            self.show_error(f"Ошибка при удалении пользователя: {ex}")
        finally:
            if con:
                con.close()

    # Метод для получения списка всех пользователей с возможностью фильтрации и сортировки
    def get_all_users(self, filter_column="", filter_text="", sort_by="", order_ascending=True):
        users = []
        con = None
        try:
            con = mysql.connector.connect(**self.config)
            query = "SELECT * FROM Users"
            params = []
            if filter_text and filter_column:
                column_map = {
                    "ID": "ID",
                    "Имя пользователя": "Username",
                    "Электронная почта": "Email",
                    "Роль": "Role"
                }
                filter_column_db = column_map.get(filter_column, "")
                if filter_column_db:
                    query += f" WHERE {filter_column_db} LIKE %s"
                    params.append(f"%{filter_text}%")
            if sort_by:
                sort_by_column = {
                    "ID": "ID",
                    "Имя пользователя": "Username",
                    "Электронная почта": "Email",
                    "Роль": "Role"
                }.get(sort_by, "ID")
                order = "ASC" if order_ascending else "DESC"
                query += f" ORDER BY {sort_by_column} {order}"
            cur = con.cursor()
            cur.execute(query, tuple(params))
            rows = cur.fetchall()
            for row in rows:
                user = User(row[0], row[1], row[2], row[3], row[4], row[5])
                users.append(user)
        except mysql.connector.Error as ex:
            self.show_error(f"Ошибка при получении списка пользователей: {ex}")
        finally:
            if con:
                con.close()
        return users

    # Метод для отображения сообщений об ошибках
    def show_error(self, message):
        msg = QMessageBox()
        msg.setIcon(QMessageBox.Icon.Critical)
        msg.setWindowTitle("Ошибка")
        msg.setText(message)
        msg.exec()
