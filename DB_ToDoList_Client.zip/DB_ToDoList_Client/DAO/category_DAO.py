import mysql.connector
from PyQt6.QtWidgets import QMessageBox
from Models.category import Category
from database_config import DatabaseConfig

class CategoryDAO:
    def __init__(self):
        self.config = DatabaseConfig.get_config()

    # Метод для добавления категории в базу данных
    def add_category(self, category):
        con = None
        try:
            con = mysql.connector.connect(**self.config)
            query = "INSERT INTO Categories (CategoryName) VALUES (%s)"
            cur = con.cursor()
            cur.execute(query, (category.get_category_name(),))
            category.set_category_id(cur.lastrowid)
            con.commit()
        except mysql.connector.Error as ex:
            self.show_error(f"Ошибка при добавлении категории: {ex}")
        finally:
            if con:
                con.close()

    # Метод для получения информации о категории по ее ID
    def get_category(self, category_id):
        category = None
        con = None
        try:
            con = mysql.connector.connect(**self.config)
            query = "SELECT * FROM Categories WHERE ID = %s"
            cur = con.cursor()
            cur.execute(query, (category_id,))
            row = cur.fetchone()
            if row:
                category = Category(row[0], row[1])
        except mysql.connector.Error as ex:
            self.show_error(f"Ошибка при получении данных категории: {ex}")
        finally:
            if con:
                con.close()
        return category

    # Метод для обновления информации о категории
    def update_category(self, category):
        con = None
        try:
            con = mysql.connector.connect(**self.config)
            query = "UPDATE Categories SET CategoryName = %s WHERE ID = %s"
            cur = con.cursor()
            cur.execute(query, (category.get_category_name(), category.get_category_id()))
            con.commit()
        except mysql.connector.Error as ex:
            self.show_error(f"Ошибка при обновлении данных категории: {ex}")
        finally:
            if con:
                con.close()

    # Метод для удаления информации о категории по ее ID
    def delete_category(self, category_id):
        con = None
        try:
            con = mysql.connector.connect(**self.config)
            query = "DELETE FROM Categories WHERE ID = %s"
            cur = con.cursor()
            cur.execute(query, (category_id,))
            con.commit()
        except mysql.connector.Error as ex:
            self.show_error(f"Ошибка при удалении категории: {ex}")
        finally:
            if con:
                con.close()

    # Метод для получения списка всех категорий с возможностью фильтрации и сортировки
    def get_all_categories(self, filter_column="", filter_text="", sort_by="", order_ascending=True):
        categories = []
        con = None
        try:
            con = mysql.connector.connect(**self.config)
            query = "SELECT * FROM Categories"
            parameters = []
            if filter_text and filter_column:
                column_map = {
                    "ID": "ID",
                    "Название категории": "CategoryName"
                }
                filter_column_db = column_map.get(filter_column, "")
                if filter_column_db:
                    query += f" WHERE {filter_column_db} LIKE %s"
                    parameters.append(f"%{filter_text}%")
            if sort_by:
                sort_by_column = {
                    "ID": "ID",
                    "Название категории": "CategoryName"
                }.get(sort_by, "ID")
                order = "ASC" if order_ascending else "DESC"
                query += f" ORDER BY {sort_by_column} {order}"
            cur = con.cursor()
            cur.execute(query, parameters)
            rows = cur.fetchall()
            for row in rows:
                category = Category(row[0], row[1])
                categories.append(category)
        except mysql.connector.Error as ex:
            self.show_error(f"Ошибка при получении списка категорий: {ex}")
        finally:
            if con:
                con.close()
        return categories

    # Метод для отображения сообщений об ошибках
    def show_error(self, message):
        msg = QMessageBox()
        msg.setIcon(QMessageBox.Icon.Critical)
        msg.setWindowTitle("Ошибка")
        msg.setText(message)
        msg.exec()
