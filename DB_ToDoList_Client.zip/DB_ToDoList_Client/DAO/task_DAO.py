import mysql.connector
from PyQt6.QtWidgets import QMessageBox
from Models.task import Task
from database_config import DatabaseConfig

class TaskDAO:
    def __init__(self):
        self.config = DatabaseConfig.get_config()

    # Метод для добавления задачи в базу данных
    def add_task(self, task):
        con = None
        try:
            con = mysql.connector.connect(**self.config)
            query = """
                INSERT INTO Tasks (UserID, Title, TaskDescription, StartDate, EndDate, CategoryID, Status)
                VALUES (%s, %s, %s, %s, %s, %s, %s)
            """
            cur = con.cursor()
            cur.execute(query, (task.get_user_id(), task.get_title(), task.get_task_description(),
                                task.get_start_date(), task.get_end_date(), task.get_category_id(), task.get_status()))
            task.set_task_id(cur.lastrowid)
            con.commit()
        except mysql.connector.Error as ex:
            self.show_error(f"Ошибка при добавлении задачи: {ex}")
        finally:
            if con:
                con.close()

    # Метод для получения информации о задаче по ее ID
    def get_task(self, task_id):
        task = None
        con = None
        try:
            con = mysql.connector.connect(**self.config)
            query = """
                SELECT Tasks.ID, Users.Username, Tasks.Title, Tasks.TaskDescription, 
                       Tasks.StartDate, Tasks.EndDate, Categories.CategoryName, Tasks.Status 
                FROM Tasks 
                JOIN Users ON Tasks.UserID = Users.ID
                JOIN Categories ON Tasks.CategoryID = Categories.ID 
                WHERE Tasks.ID = %s
            """
            cur = con.cursor()
            cur.execute(query, (task_id,))
            row = cur.fetchone()
            if row:
                task = Task(row[0], row[1], row[2], row[3], row[4], row[5], row[6], row[7])
        except mysql.connector.Error as ex:
            self.show_error(f"Ошибка при получении данных задачи: {ex}")
        finally:
            if con:
                con.close()
        return task

    # Метод для обновления информации о задаче
    def update_task(self, task):
        con = None
        try:
            con = mysql.connector.connect(**self.config)
            query = """
                UPDATE Tasks SET UserID = %s, Title = %s, TaskDescription = %s, StartDate = %s, EndDate = %s,
                CategoryID = %s, Status = %s WHERE ID = %s
            """
            cur = con.cursor()
            cur.execute(query, (task.get_user_id(), task.get_title(), task.get_task_description(),
                                task.get_start_date(), task.get_end_date(), task.get_category_id(), task.get_status(),
                                task.get_task_id()))
            con.commit()
        except mysql.connector.Error as ex:
            self.show_error(f"Ошибка при обновлении данных задачи: {ex}")
        finally:
            if con:
                con.close()

    # Метод для удаления информации о задаче по ее ID
    def delete_task(self, task_id):
        con = None
        try:
            con = mysql.connector.connect(**self.config)
            query = "DELETE FROM Tasks WHERE ID = %s"
            cur = con.cursor()
            cur.execute(query, (task_id,))
            con.commit()
        except mysql.connector.Error as ex:
            self.show_error(f"Ошибка при удалении задачи: {ex}")
        finally:
            if con:
                con.close()

    # Метод для получения списка всех задач с возможностью фильтрации и сортировки
    def get_all_tasks(self, filter_column="", filter_text="", sort_by="", order_ascending=True):
        tasks = []
        con = None
        try:
            con = mysql.connector.connect(**self.config)
            query = """
                SELECT Tasks.ID, Users.Username, Tasks.Title, Tasks.TaskDescription, 
                       Tasks.StartDate, Tasks.EndDate, Categories.CategoryName, Tasks.Status 
                FROM Tasks 
                JOIN Users ON Tasks.UserID = Users.ID
                JOIN Categories ON Tasks.CategoryID = Categories.ID
            """
            if filter_text and filter_column:
                column_map = {
                    "ID": "Tasks.ID",
                    "Имя пользователя": "Users.Username",
                    "Название": "Tasks.Title",
                    "Описание": "Tasks.TaskDescription",
                    "Дата начала": "Tasks.StartDate",
                    "Дата окончания": "Tasks.EndDate",
                    "Категория": "Categories.CategoryName",
                    "Статус": "Tasks.Status"
                }
                filter_column_db = column_map.get(filter_column, "")
                if filter_column_db:
                    query += f" WHERE {filter_column_db} LIKE %s"
            if sort_by:
                sort_by_column = {
                    "ID": "Tasks.ID",
                    "Имя пользователя": "Users.Username",
                    "Название": "Tasks.Title",
                    "Описание": "Tasks.TaskDescription",
                    "Дата начала": "Tasks.StartDate",
                    "Дата окончания": "Tasks.EndDate",
                    "Категория": "Categories.CategoryName",
                    "Статус": "Tasks.Status"
                }.get(sort_by, "Tasks.ID")
                order = "ASC" if order_ascending else "DESC"
                query += f" ORDER BY {sort_by_column} {order}"
            cur = con.cursor()
            if filter_text and filter_column:
                cur.execute(query, (f"%{filter_text}%",))
            else:
                cur.execute(query)
            rows = cur.fetchall()
            for row in rows:
                task = Task(row[0], row[1], row[2], row[3], row[4], row[5], row[6], row[7])
                tasks.append(task)
        except mysql.connector.Error as ex:
            self.show_error(f"Ошибка при получении списка задач: {ex}")
        finally:
            if con:
                con.close()
        return tasks

    def get_user_tasks(self, user_id, filter_column="", filter_text="", sort_by="", order_ascending=True):
        tasks = []
        con = None
        try:
            con = mysql.connector.connect(**self.config)
            query = """
                SELECT Tasks.ID, Users.Username, Tasks.Title, Tasks.TaskDescription, 
                       Tasks.StartDate, Tasks.EndDate, Categories.CategoryName, Tasks.Status 
                FROM Tasks 
                JOIN Users ON Tasks.UserID = Users.ID
                JOIN Categories ON Tasks.CategoryID = Categories.ID
                WHERE Tasks.UserID = %s
            """
            params = [user_id]
            if filter_text and filter_column:
                column_map = {
                    "ID": "Tasks.ID",
                    "Название": "Tasks.Title",
                    "Описание": "Tasks.TaskDescription",
                    "Дата начала": "Tasks.StartDate",
                    "Дата окончания": "Tasks.EndDate",
                    "Категория": "Categories.CategoryName",
                    "Статус": "Tasks.Status"
                }
                filter_column_db = column_map.get(filter_column, "")
                if filter_column_db:
                    query += f" AND {filter_column_db} LIKE %s"
                    params.append(f"%{filter_text}%")
            if sort_by:
                sort_by_column = {
                    "ID": "Tasks.ID",
                    "Название": "Tasks.Title",
                    "Описание": "Tasks.TaskDescription",
                    "Дата начала": "Tasks.StartDate",
                    "Дата окончания": "Tasks.EndDate",
                    "Категория": "Categories.CategoryName",
                    "Статус": "Tasks.Status"
                }.get(sort_by, "Tasks.ID")
                order = "ASC" if order_ascending else "DESC"
                query += f" ORDER BY {sort_by_column} {order}"
            cur = con.cursor()
            cur.execute(query, tuple(params))
            rows = cur.fetchall()
            for row in rows:
                task = Task(row[0], row[1], row[2], row[3], row[4], row[5], row[6], row[7])
                tasks.append(task)
        except mysql.connector.Error as ex:
            self.show_error(f"Ошибка при получении списка задач: {ex}")
        finally:
            if con:
                con.close()
        return tasks

    # Метод для отображения сообщений об ошибках
    def show_error(self, message):
        msg = QMessageBox()
        msg.setIcon(QMessageBox.Icon.Critical)
        msg.setWindowTitle("Ошибка")
        msg.setText(message)
        msg.exec()