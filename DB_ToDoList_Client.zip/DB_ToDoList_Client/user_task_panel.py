from PyQt6.QtCore import Qt
from PyQt6.QtWidgets import QMessageBox, QPushButton, QHBoxLayout, QHeaderView, QTableView, QCheckBox, QComboBox, \
    QLabel, QVBoxLayout, QLineEdit, QWidget
from AddEditControllers.add_edit_task_dialog import AddEditTaskDialog
from DAO.task_DAO import TaskDAO
from TableModels.task_table_model import TaskTableModel
from session import Session

class UserTaskPanel(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        # Инициализация DAO для работы с задачами
        self.task_dao = TaskDAO()
        self.session = Session()
        self.user_id = self.session.get_user_id()
        self.init_ui()
        self.update_tasks_table_model()

    def init_ui(self):
        # Создание основного макета
        self.layout = QVBoxLayout()

        # Создание и настройка заголовка панели
        self.title_label = QLabel("Мои задачи")
        self.title_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.title_label.setStyleSheet("font-size: 24px; font-weight: bold;")
        self.layout.addWidget(self.title_label)

        # Создание макета для фильтров
        self.filter_layout = QHBoxLayout()

        self.filter_label = QLabel("Фильтр:")
        self.filter_layout.addWidget(self.filter_label)

        # Выпадающий список для выбора столбца для фильтрации
        self.filter_column_combobox = QComboBox()
        self.filter_column_combobox.addItems(
            ["ID", "Название", "Описание", "Дата начала", "Дата окончания", "Категория", "Статус"])
        self.filter_column_combobox.currentIndexChanged.connect(self.apply_filter_and_sort)
        self.filter_layout.addWidget(self.filter_column_combobox)

        # Поле ввода для текста фильтрации
        self.filter_entry = QLineEdit()
        self.filter_entry.textChanged.connect(self.apply_filter_and_sort)
        self.filter_layout.addWidget(self.filter_entry)

        self.sort_label = QLabel("Сортировка:")
        self.filter_layout.addWidget(self.sort_label)

        # Выпадающий список для выбора столбца для сортировки
        self.sort_combobox = QComboBox()
        self.sort_combobox.addItems(
            ["ID", "Название", "Описание", "Дата начала", "Дата окончания", "Категория", "Статус"])
        self.sort_combobox.currentIndexChanged.connect(self.apply_filter_and_sort)
        self.filter_layout.addWidget(self.sort_combobox)

        # Чекбокс для выбора порядка сортировки
        self.order_checkbox = QCheckBox("По возрастанию")
        self.order_checkbox.setChecked(True)
        self.order_checkbox.stateChanged.connect(self.apply_filter_and_sort)
        self.filter_layout.addWidget(self.order_checkbox)

        self.layout.addLayout(self.filter_layout)

        # Создание таблицы для отображения задач
        self.tasks_table = QTableView()
        self.tasks_table.setSelectionBehavior(QTableView.SelectionBehavior.SelectRows)
        self.tasks_table.setSelectionMode(QTableView.SelectionMode.SingleSelection)
        self.tasks_table.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeMode.Stretch)
        self.layout.addWidget(self.tasks_table)

        # Создание макета для кнопок управления
        self.button_layout = QHBoxLayout()

        self.add_button = QPushButton("Добавить")
        self.add_button.clicked.connect(self.add_task)
        self.button_layout.addWidget(self.add_button)

        self.edit_button = QPushButton("Изменить")
        self.edit_button.clicked.connect(self.edit_task)
        self.button_layout.addWidget(self.edit_button)

        self.delete_button = QPushButton("Удалить")
        self.delete_button.clicked.connect(self.delete_task)
        self.button_layout.addWidget(self.delete_button)

        self.layout.addLayout(self.button_layout)

        self.setLayout(self.layout)

    def update_tasks_table_model(self, filter_column="", filter_text="", sort_by="", order_ascending=True):
        # Обновление данных в модели таблицы задач
        tasks = self.task_dao.get_user_tasks(self.user_id, filter_column, filter_text, sort_by, order_ascending)
        self.tasks_table_model = TaskTableModel(tasks)
        self.tasks_table.setModel(self.tasks_table_model)

    def apply_filter_and_sort(self):
        # Применение фильтрации и сортировки на основе выбранных параметров
        filter_column = self.filter_column_combobox.currentText()
        filter_text = self.filter_entry.text()
        sort_by = self.sort_combobox.currentText()
        order_ascending = self.order_checkbox.isChecked()
        self.update_tasks_table_model(filter_column, filter_text, sort_by, order_ascending)

    def add_task(self):
        # Добавление новой задачи
        add_dialog = AddEditTaskDialog(self, task_dao=self.task_dao, user_id=self.user_id)
        if add_dialog.exec():
            self.update_tasks_table_model()

    def edit_task(self):
        # Редактирование выбранной задачи
        selected_indexes = self.tasks_table.selectionModel().selectedRows()
        if len(selected_indexes) == 1:
            index = selected_indexes[0].row()
            task = self.tasks_table_model.get_task_at(index)
            edit_dialog = AddEditTaskDialog(self, task=task, task_dao=self.task_dao, user_id=self.user_id)
            if edit_dialog.exec():
                self.update_tasks_table_model()
        else:
            QMessageBox.warning(self, "Внимание", "Пожалуйста, выберите одну задачу для редактирования.")

    def delete_task(self):
        # Удаление выбранной задачи
        selected_indexes = self.tasks_table.selectionModel().selectedRows()
        if selected_indexes:
            confirm = QMessageBox.question(self, "Подтверждение удаления",
                                           "Вы уверены, что хотите удалить выбранные задачи?")
            if confirm == QMessageBox.StandardButton.Yes:
                for index in selected_indexes:
                    task = self.tasks_table_model.get_task_at(index.row())
                    self.task_dao.delete_task(task.get_task_id())
                self.update_tasks_table_model()
        else:
            QMessageBox.warning(self, "Внимание", "Пожалуйста, выберите задачу для удаления.")
